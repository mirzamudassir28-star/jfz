# JFZ Study Lens

AI-powered study companion by **Jamiah Fatimah Tuz Zahra Online Educational Centre**.
Upload PDFs, images, screenshots or handwritten notes → OCR → Translate (Urdu / Hindi / English) → Explain · Summarize · Notes · MCQ · Flashcards · Voice reading · Live camera scanner. No login required.

## Stack
- **Backend:** FastAPI (Python 3.11) + MongoDB + `emergentintegrations` (Gemini 3 Flash for vision OCR & text)
- **Frontend:** React 19 + Tailwind 3 + shadcn/ui + framer-motion + sonner toasts
- **TTS:** Browser Web Speech API (free, supports Urdu / Hindi / English)

## Run locally

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
# Open .env and paste your EMERGENT_LLM_KEY (get it from Emergent dashboard)
uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

### 2. Frontend
```bash
cd frontend
yarn install
# Edit .env: set REACT_APP_BACKEND_URL to your backend URL
yarn start
```

### 3. MongoDB
A local MongoDB instance must be running at the URL set in `backend/.env` (`MONGO_URL`, `DB_NAME`).

## API endpoints
- `GET  /api/`            — health
- `POST /api/extract`     — file upload → OCR text
- `POST /api/translate`   — text → Urdu / Hindi / English
- `POST /api/explain`     — 4 styles (simply / detailed / teacher / child)
- `POST /api/ask`         — Q&A grounded in document
- `POST /api/summary`     — short / detailed / bullet
- `POST /api/notes`       — quick / revision / exam
- `POST /api/mcq`         — 10 / 20 / 50 with scoring
- `POST /api/flashcards`  — front/back study cards

## Important
- Replace `EMERGENT_LLM_KEY` in `backend/.env` with your own key.
- Set `REACT_APP_BACKEND_URL` in `frontend/.env` to point to your deployed backend.
