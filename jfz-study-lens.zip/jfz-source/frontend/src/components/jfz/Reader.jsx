import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
    Copy,
    Loader2,
    Languages,
    Sparkles,
    MessageSquare,
    BookOpen,
    NotebookPen,
    ListChecks,
    Layers,
    Send,
    RefreshCw,
    Wand2,
    FileText,
} from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuLabel,
    DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import VoicePlayer from "@/components/jfz/VoicePlayer";
import Flashcards from "@/components/jfz/Flashcards";
import MCQQuiz from "@/components/jfz/MCQQuiz";
import {
    translate,
    explain,
    askQuestion,
    getSummary,
    getNotes,
} from "@/lib/api";

const LANGS = [
    { id: "english", label: "English" },
    { id: "urdu", label: "اردو" },
    { id: "hindi", label: "हिन्दी" },
];
const EXPLAIN_STYLES = [
    { id: "simply", label: "Explain Simply" },
    { id: "detailed", label: "Explain In Detail" },
    { id: "teacher", label: "Like A Teacher" },
    { id: "child", label: "Like A Child" },
];
const SUMMARY_MODES = [
    { id: "short", label: "Short" },
    { id: "detailed", label: "Detailed" },
    { id: "bullet", label: "Bullet Points" },
];
const NOTES_MODES = [
    { id: "quick", label: "Quick Notes" },
    { id: "revision", label: "Revision Notes" },
    { id: "exam", label: "Exam Notes" },
];

function scriptClass(lang) {
    return lang === "urdu" ? "font-script-urdu" : lang === "hindi" ? "font-script-hindi" : "";
}

function copy(text) {
    navigator.clipboard?.writeText(text);
    toast.success("Copied to clipboard");
}

export default function Reader({ session, onReset }) {
    const [tab, setTab] = useState("text");
    const [activeLang, setActiveLang] = useState(session.detected_language || "english");
    const [translations, setTranslations] = useState({}); // {english, urdu, hindi}
    const [translating, setTranslating] = useState(false);

    const [aiOutput, setAiOutput] = useState(""); // for explanation/summary/notes/answer
    const [aiTitle, setAiTitle] = useState("");
    const [aiBusy, setAiBusy] = useState(false);
    const [question, setQuestion] = useState("");

    // Use the active language's text as the working text for all AI ops
    const workingText = useMemo(() => {
        if (activeLang === (session.detected_language || "english")) return session.text;
        return translations[activeLang] || session.text;
    }, [activeLang, session, translations]);

    const switchLanguage = async (lang) => {
        setActiveLang(lang);
        setAiOutput("");
        if (lang === (session.detected_language || "english")) return;
        if (translations[lang]) return;
        setTranslating(true);
        try {
            const t = await translate(session.text, lang);
            setTranslations((p) => ({ ...p, [lang]: t }));
            toast.success(`Translated to ${lang}`);
        } catch (e) {
            toast.error("Translation failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setTranslating(false);
        }
    };

    const runExplain = async (style) => {
        setAiBusy(true);
        setAiTitle(EXPLAIN_STYLES.find((s) => s.id === style)?.label || "Explanation");
        setAiOutput("");
        try {
            const o = await explain(workingText, style, activeLang);
            setAiOutput(o);
        } catch (e) {
            toast.error("Failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setAiBusy(false);
        }
    };

    const runSummary = async (mode) => {
        setAiBusy(true);
        setAiTitle(`Summary · ${SUMMARY_MODES.find((m) => m.id === mode)?.label}`);
        setAiOutput("");
        try {
            const o = await getSummary(workingText, mode, activeLang);
            setAiOutput(o);
        } catch (e) {
            toast.error("Failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setAiBusy(false);
        }
    };

    const runNotes = async (mode) => {
        setAiBusy(true);
        setAiTitle(`Notes · ${NOTES_MODES.find((m) => m.id === mode)?.label}`);
        setAiOutput("");
        try {
            const o = await getNotes(workingText, mode, activeLang);
            setAiOutput(o);
        } catch (e) {
            toast.error("Failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setAiBusy(false);
        }
    };

    const runAsk = async () => {
        if (!question.trim()) return;
        setAiBusy(true);
        setAiTitle(`Q: ${question.slice(0, 60)}${question.length > 60 ? "…" : ""}`);
        setAiOutput("");
        try {
            const o = await askQuestion(workingText, question, activeLang);
            setAiOutput(o);
        } catch (e) {
            toast.error("Failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setAiBusy(false);
        }
    };

    return (
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-8 sm:py-12">
            {/* Header */}
            <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
                <div>
                    <div className="text-[11px] uppercase tracking-[0.22em] text-[hsl(var(--accent))]">Reader</div>
                    <h2 className="mt-1 font-display text-3xl sm:text-4xl font-semibold leading-tight flex items-center gap-3">
                        <FileText className="size-7 text-[hsl(var(--primary))]" />
                        {session.filename || "Your document"}
                    </h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                        {workingText.length.toLocaleString()} characters · detected {session.detected_language || "english"}
                    </p>
                </div>
                <Button variant="outline" onClick={onReset} className="rounded-full" data-testid="reader-reset-btn">
                    <RefreshCw className="size-4" /> Upload another
                </Button>
            </div>

            {/* Language switcher */}
            <div className="flex flex-wrap items-center gap-2 mb-4" data-testid="language-switcher">
                <span className="text-xs uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1.5">
                    <Languages className="size-3.5" /> Reading in
                </span>
                {LANGS.map((l) => (
                    <button
                        key={l.id}
                        onClick={() => switchLanguage(l.id)}
                        data-testid={`lang-${l.id}-btn`}
                        className={`rounded-full border px-4 py-1.5 text-sm transition-all ${
                            activeLang === l.id
                                ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-primary-foreground"
                                : "border-border hover:border-[hsl(var(--primary))]/60 hover:bg-muted"
                        }`}
                    >
                        {l.label}
                    </button>
                ))}
                {translating && (
                    <span className="text-xs text-muted-foreground inline-flex items-center gap-1">
                        <Loader2 className="size-3 animate-spin" /> translating…
                    </span>
                )}
            </div>

            <div className="grid lg:grid-cols-12 gap-6">
                {/* Left — Text / Tabs */}
                <div className="lg:col-span-7">
                    <Tabs value={tab} onValueChange={setTab} className="w-full" data-testid="reader-tabs">
                        <TabsList className="rounded-full bg-muted p-1 w-full overflow-x-auto flex justify-start sm:justify-center">
                            <TabsTrigger value="text" data-testid="tab-text" className="rounded-full px-4">
                                <BookOpen className="size-4" /> Text
                            </TabsTrigger>
                            <TabsTrigger value="ask" data-testid="tab-ask" className="rounded-full px-4">
                                <MessageSquare className="size-4" /> Ask
                            </TabsTrigger>
                            <TabsTrigger value="mcq" data-testid="tab-mcq" className="rounded-full px-4">
                                <ListChecks className="size-4" /> MCQs
                            </TabsTrigger>
                            <TabsTrigger value="flash" data-testid="tab-flash" className="rounded-full px-4">
                                <Layers className="size-4" /> Flashcards
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="text" className="mt-4">
                            <div className="rounded-2xl border border-border bg-card p-5 sm:p-7">
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="font-display text-xl font-semibold">Extracted text</h3>
                                    <Button size="sm" variant="ghost" onClick={() => copy(workingText)} data-testid="copy-text-btn">
                                        <Copy className="size-4" /> Copy
                                    </Button>
                                </div>
                                <div className="mt-2">
                                    <VoicePlayer text={workingText} language={activeLang} testIdPrefix="reader-voice" />
                                </div>
                                <div
                                    data-testid="extracted-text"
                                    className={`mt-5 max-h-[60vh] overflow-y-auto whitespace-pre-wrap leading-relaxed text-foreground/90 ${scriptClass(activeLang)}`}
                                >
                                    {workingText || "No text extracted."}
                                </div>
                            </div>
                        </TabsContent>

                        <TabsContent value="ask" className="mt-4">
                            <div className="rounded-2xl border border-border bg-card p-5 sm:p-7">
                                <h3 className="font-display text-xl font-semibold">Ask about this document</h3>
                                <p className="text-sm text-muted-foreground mt-1">
                                    Try: &quot;Explain this paragraph&quot;, &quot;Summarise this chapter&quot;, &quot;Give important points&quot;.
                                </p>
                                <div className="mt-4 flex flex-col sm:flex-row gap-3">
                                    <Textarea
                                        rows={2}
                                        placeholder="Type your question…"
                                        value={question}
                                        onChange={(e) => setQuestion(e.target.value)}
                                        data-testid="ask-input"
                                        className="resize-none"
                                    />
                                    <Button
                                        onClick={runAsk}
                                        disabled={aiBusy || !question.trim()}
                                        className="rounded-full sm:self-end bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                                        data-testid="ask-submit-btn"
                                    >
                                        {aiBusy ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
                                        Ask
                                    </Button>
                                </div>
                                <div className="mt-4 flex flex-wrap gap-2">
                                    {[
                                        "Explain this paragraph",
                                        "What is the meaning?",
                                        "Summarise this chapter",
                                        "Create questions from this topic",
                                        "Give important points",
                                    ].map((p) => (
                                        <button
                                            key={p}
                                            onClick={() => setQuestion(p)}
                                            data-testid={`ask-suggest-${p.replace(/\s+/g, "-").toLowerCase()}`}
                                            className="rounded-full border border-border bg-background px-3 py-1 text-xs hover:border-[hsl(var(--primary))]/60 hover:bg-muted"
                                        >
                                            {p}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </TabsContent>

                        <TabsContent value="mcq" className="mt-4">
                            <MCQQuiz text={workingText} language={activeLang} />
                        </TabsContent>

                        <TabsContent value="flash" className="mt-4">
                            <Flashcards text={workingText} language={activeLang} />
                        </TabsContent>
                    </Tabs>
                </div>

                {/* Right — AI Actions + Output */}
                <div className="lg:col-span-5 space-y-4">
                    <div className="rounded-2xl border border-border bg-card p-5">
                        <div className="text-[11px] uppercase tracking-wider text-[hsl(var(--accent))]">AI tools</div>
                        <h3 className="mt-1 font-display text-2xl font-semibold">Turn this into…</h3>
                        <div className="mt-4 grid grid-cols-2 gap-2">
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline" className="rounded-xl justify-start" data-testid="explain-dropdown-btn">
                                        <Sparkles className="size-4 text-[hsl(var(--accent))]" /> Explain
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuLabel>Explanation style</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    {EXPLAIN_STYLES.map((s) => (
                                        <DropdownMenuItem key={s.id} onClick={() => runExplain(s.id)} data-testid={`explain-${s.id}`}>
                                            {s.label}
                                        </DropdownMenuItem>
                                    ))}
                                </DropdownMenuContent>
                            </DropdownMenu>

                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline" className="rounded-xl justify-start" data-testid="summary-dropdown-btn">
                                        <BookOpen className="size-4 text-[hsl(var(--accent))]" /> Summary
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuLabel>Summary mode</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    {SUMMARY_MODES.map((m) => (
                                        <DropdownMenuItem key={m.id} onClick={() => runSummary(m.id)} data-testid={`summary-${m.id}`}>
                                            {m.label}
                                        </DropdownMenuItem>
                                    ))}
                                </DropdownMenuContent>
                            </DropdownMenu>

                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline" className="rounded-xl justify-start" data-testid="notes-dropdown-btn">
                                        <NotebookPen className="size-4 text-[hsl(var(--accent))]" /> Notes
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuLabel>Notes type</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    {NOTES_MODES.map((m) => (
                                        <DropdownMenuItem key={m.id} onClick={() => runNotes(m.id)} data-testid={`notes-${m.id}`}>
                                            {m.label}
                                        </DropdownMenuItem>
                                    ))}
                                </DropdownMenuContent>
                            </DropdownMenu>

                            <Button
                                variant="outline"
                                className="rounded-xl justify-start"
                                onClick={() => setTab("ask")}
                                data-testid="goto-ask-btn"
                            >
                                <MessageSquare className="size-4 text-[hsl(var(--accent))]" /> Ask Q&amp;A
                            </Button>
                        </div>
                    </div>

                    <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className="rounded-2xl border border-border bg-card p-5 min-h-[260px]"
                        data-testid="ai-output-panel"
                    >
                        <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2">
                                <Wand2 className="size-4 text-[hsl(var(--primary))]" />
                                <span className="font-medium">{aiTitle || "AI output"}</span>
                            </div>
                            {aiOutput && (
                                <Button size="sm" variant="ghost" onClick={() => copy(aiOutput)} data-testid="copy-ai-btn">
                                    <Copy className="size-4" /> Copy
                                </Button>
                            )}
                        </div>
                        {aiOutput && (
                            <div className="mt-3">
                                <VoicePlayer text={aiOutput} language={activeLang} testIdPrefix="ai-voice" />
                            </div>
                        )}
                        <div
                            className={`mt-4 max-h-[55vh] overflow-y-auto whitespace-pre-wrap leading-relaxed text-foreground/90 ${scriptClass(
                                activeLang,
                            )}`}
                        >
                            {aiBusy ? (
                                <div className="flex items-center gap-2 text-muted-foreground">
                                    <Loader2 className="size-4 animate-spin" /> Generating…
                                </div>
                            ) : aiOutput ? (
                                aiOutput
                            ) : (
                                <span className="text-muted-foreground text-sm">
                                    Pick an AI tool above to generate explanations, summaries, notes or ask a question.
                                </span>
                            )}
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
}
