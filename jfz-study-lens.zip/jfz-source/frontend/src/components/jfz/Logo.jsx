import React from "react";

export default function Logo({ size = 44, withText = true }) {
    return (
        <div className="flex items-center gap-3" data-testid="jfz-logo">
            <div
                className="relative shrink-0 rounded-full overflow-hidden ring-1 ring-[hsl(var(--accent))]/60 shadow-[0_2px_14px_-2px_rgba(11,110,79,0.35)]"
                style={{ width: size, height: size }}
            >
                <img
                    src="/brand/jfz-logo.jpg"
                    alt="Jamiah Fatimah Tuz Zahra logo"
                    className="absolute inset-0 h-full w-full object-cover"
                    draggable={false}
                />
            </div>
            {withText && (
                <div className="leading-tight">
                    <div className="font-display text-xl sm:text-2xl font-semibold tracking-tight">
                        JFZ <span className="text-[hsl(var(--primary))]">Study Lens</span>
                    </div>
                    <div className="text-[10px] sm:text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                        Learn · Translate · Understand
                    </div>
                </div>
            )}
        </div>
    );
}
