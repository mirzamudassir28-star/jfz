import React from "react";
import { motion } from "framer-motion";
import {
    ScanText,
    Languages,
    Volume2,
    Sparkles,
    MessageSquare,
    BookOpen,
    NotebookPen,
    ListChecks,
    Layers,
    FileAudio,
    Camera,
    Smartphone,
} from "lucide-react";

const FEATURES = [
    { icon: ScanText, t: "OCR Extraction", d: "Books, notes, screenshots, printed pages and handwriting — extracted with AI vision." },
    { icon: Languages, t: "3-Language Translation", d: "One-click switching between Urdu, Hindi and English — format preserved." },
    { icon: Volume2, t: "Voice Reading", d: "Natural speech with play, pause, resume, stop and speed control in 3 languages." },
    { icon: Sparkles, t: "AI Explanations", d: "Explain simply, in detail, like a teacher, or like a child — your choice." },
    { icon: MessageSquare, t: "Ask About Document", d: "Answers come only from your uploaded content, not the open web." },
    { icon: BookOpen, t: "Summary Generator", d: "Short, detailed or bullet-point summaries on demand." },
    { icon: NotebookPen, t: "Notes Generator", d: "Quick, revision and exam-focused notes — copyable in a tap." },
    { icon: ListChecks, t: "MCQ Generator", d: "Create 10, 20 or 50 MCQs with instant scoring." },
    { icon: Layers, t: "Flashcards", d: "Auto-built study deck — flip, shuffle, repeat until mastered." },
    { icon: FileAudio, t: "PDF Audio Reader", d: "Listen to long documents page by page, hands-free." },
    { icon: Camera, t: "Live Camera Scanner", d: "Open the camera, point at any text and scan instantly on mobile." },
    { icon: Smartphone, t: "Mobile-First", d: "Fast, smooth and beautiful on phones, tablets and desktops alike." },
];

export default function Features() {
    return (
        <section id="features" className="scroll-mt-24 border-t border-border bg-muted/30 geo-grain">
            <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16 sm:py-24">
                <div className="max-w-2xl">
                    <div className="text-[11px] uppercase tracking-[0.22em] text-[hsl(var(--accent))]">What it does</div>
                    <h2 className="mt-2 font-display text-3xl sm:text-5xl font-semibold leading-tight">
                        A complete <span className="text-[hsl(var(--primary))]">study companion,</span> in one screen.
                    </h2>
                    <p className="mt-4 text-muted-foreground leading-relaxed">
                        JFZ Study Lens combines OCR, translation, AI explanation, audio narration and revision tools — purpose-built for
                        students, teachers, madarsa learners and parents.
                    </p>
                </div>

                <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {FEATURES.map((f, i) => (
                        <motion.div
                            key={f.t}
                            initial={{ opacity: 0, y: 14 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.4, delay: (i % 6) * 0.05 }}
                            className="group rounded-2xl border border-border bg-card p-5 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-[hsl(var(--primary))]/10 hover:border-[hsl(var(--primary))]/40"
                        >
                            <div className="size-10 rounded-xl grid place-items-center bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))] group-hover:bg-[hsl(var(--accent))]/15 group-hover:text-[hsl(var(--accent-foreground))] transition-colors">
                                <f.icon className="size-5" />
                            </div>
                            <h3 className="mt-4 font-display text-xl font-semibold">{f.t}</h3>
                            <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{f.d}</p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}
