import React, { useState } from "react";
import { Moon, Sun, Camera, Menu, X } from "lucide-react";
import Logo from "@/components/jfz/Logo";
import { Button } from "@/components/ui/button";

const links = [
    { id: "home", label: "Home" },
    { id: "upload", label: "Upload" },
    { id: "features", label: "Features" },
    { id: "about", label: "About" },
];

export default function Navbar({ theme, setTheme, onScan }) {
    const [open, setOpen] = useState(false);
    const go = (id) => {
        if (id === "home") window.scrollTo({ top: 0, behavior: "smooth" });
        else document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
        setOpen(false);
    };

    return (
        <header className="sticky top-0 z-40 glass border-b border-border" data-testid="navbar">
            <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 px-5 sm:px-8 py-3 sm:py-4">
                <button onClick={() => go("home")} className="flex items-center" data-testid="nav-logo-btn" aria-label="JFZ home">
                    <Logo size={42} />
                </button>

                <nav className="hidden md:flex items-center gap-7">
                    {links.map((l) => (
                        <button
                            key={l.id}
                            onClick={() => go(l.id)}
                            data-testid={`nav-${l.id}-btn`}
                            className="text-sm font-medium text-foreground/70 transition-colors hover:text-[hsl(var(--primary))]"
                        >
                            {l.label}
                        </button>
                    ))}
                </nav>

                <div className="flex items-center gap-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onScan}
                        className="hidden sm:inline-flex border-[hsl(var(--accent))]/40 hover:bg-[hsl(var(--accent))]/10 hover:border-[hsl(var(--accent))] hover:text-[hsl(var(--accent-foreground))]"
                        data-testid="navbar-scan-btn"
                    >
                        <Camera className="size-4" />
                        Scan
                    </Button>
                    <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Toggle theme"
                        onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                        data-testid="theme-toggle-btn"
                    >
                        {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
                    </Button>
                    <Button
                        variant="ghost"
                        size="icon"
                        className="md:hidden"
                        aria-label="Open menu"
                        onClick={() => setOpen((v) => !v)}
                        data-testid="mobile-menu-btn"
                    >
                        {open ? <X className="size-5" /> : <Menu className="size-5" />}
                    </Button>
                </div>
            </div>

            {open && (
                <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl">
                    <div className="px-5 py-3 flex flex-col gap-1">
                        {links.map((l) => (
                            <button
                                key={l.id}
                                onClick={() => go(l.id)}
                                data-testid={`mobile-nav-${l.id}-btn`}
                                className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-muted"
                            >
                                {l.label}
                            </button>
                        ))}
                        <button
                            onClick={() => {
                                onScan();
                                setOpen(false);
                            }}
                            data-testid="mobile-scan-btn"
                            className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-muted flex items-center gap-2"
                        >
                            <Camera className="size-4" /> Live Scan
                        </button>
                    </div>
                </div>
            )}
        </header>
    );
}
