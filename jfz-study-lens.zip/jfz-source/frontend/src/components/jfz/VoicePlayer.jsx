import React, { useEffect, useRef, useState } from "react";
import { Play, Pause, Square, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import * as tts from "@/lib/tts";

export default function VoicePlayer({ text, language = "english", testIdPrefix = "voice" }) {
    const [state, setState] = useState("idle"); // idle | playing | paused
    const [rate, setRate] = useState(1);
    const stateRef = useRef(state);
    stateRef.current = state;

    useEffect(() => () => tts.stop(), []);
    useEffect(() => {
        // Stop when language or text changes
        tts.stop();
        setState("idle");
    }, [text, language]);

    const play = () => {
        if (state === "paused") {
            tts.resume();
            setState("playing");
            return;
        }
        if (!text?.trim()) return;
        tts.speak(text, {
            lang: language,
            rate,
            onStart: () => setState("playing"),
            onEnd: () => setState("idle"),
        });
    };
    const pause = () => {
        tts.pause();
        setState("paused");
    };
    const stop = () => {
        tts.stop();
        setState("idle");
    };

    const isPlaying = state === "playing";

    return (
        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card/70 px-4 py-3" data-testid={`${testIdPrefix}-player`}>
            <div className="relative">
                <span className={isPlaying ? "pulse-dot absolute inset-0 rounded-full" : ""} />
                <Button
                    size="icon"
                    onClick={isPlaying ? pause : play}
                    className="relative size-10 rounded-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                    data-testid={`${testIdPrefix}-play-btn`}
                    aria-label={isPlaying ? "Pause" : "Play"}
                >
                    {isPlaying ? <Pause className="size-4" /> : <Play className="size-4 ml-0.5" />}
                </Button>
            </div>
            <Button variant="outline" size="icon" onClick={stop} aria-label="Stop" data-testid={`${testIdPrefix}-stop-btn`} className="size-10 rounded-full">
                <Square className="size-3.5" />
            </Button>
            <div className="flex items-center gap-2 min-w-[160px] flex-1">
                <Volume2 className="size-4 text-muted-foreground" />
                <Slider
                    value={[rate]}
                    min={0.5}
                    max={2}
                    step={0.1}
                    onValueChange={(v) => setRate(v[0])}
                    className="flex-1"
                    data-testid={`${testIdPrefix}-speed-slider`}
                />
                <span className="text-xs tabular-nums w-10 text-muted-foreground">{rate.toFixed(1)}x</span>
            </div>
            <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{language}</span>
        </div>
    );
}
