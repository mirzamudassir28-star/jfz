import React, { useEffect, useRef, useState } from "react";
import { X, Camera as CamIcon, RefreshCw, Loader2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { extractText } from "@/lib/api";
import { toast } from "sonner";

export default function CameraScanner({ onClose, onCaptured }) {
    const videoRef = useRef(null);
    const streamRef = useRef(null);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [facing, setFacing] = useState("environment");

    const start = async (mode = facing) => {
        setError("");
        try {
            if (streamRef.current) {
                streamRef.current.getTracks().forEach((t) => t.stop());
            }
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: { ideal: mode }, width: { ideal: 1920 }, height: { ideal: 1080 } },
                audio: false,
            });
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                await videoRef.current.play();
            }
        } catch (e) {
            setError(e?.message || "Could not access camera. Please grant permission.");
        }
    };

    useEffect(() => {
        start(facing);
        return () => {
            streamRef.current?.getTracks().forEach((t) => t.stop());
            streamRef.current = null;
        };
        // eslint-disable-next-line
    }, []);

    const switchCamera = async () => {
        const next = facing === "environment" ? "user" : "environment";
        setFacing(next);
        await start(next);
    };

    const capture = async () => {
        const video = videoRef.current;
        if (!video) return;
        setBusy(true);
        try {
            const canvas = document.createElement("canvas");
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(video, 0, 0);
            const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.92));
            const file = new File([blob], `scan-${Date.now()}.jpg`, { type: "image/jpeg" });
            const data = await extractText(file);
            toast.success("Scanned!", { description: `${data.text.length} characters` });
            onCaptured(data, file.name);
        } catch (e) {
            toast.error("Scan failed", { description: e?.response?.data?.detail || e.message });
        } finally {
            setBusy(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm grid place-items-center p-4" data-testid="camera-modal">
            <div className="relative w-full max-w-3xl rounded-3xl overflow-hidden border border-border bg-card">
                <div className="absolute top-3 right-3 z-10 flex gap-2">
                    <Button size="icon" variant="secondary" onClick={switchCamera} aria-label="Switch camera" data-testid="camera-switch-btn">
                        <RefreshCw className="size-4" />
                    </Button>
                    <Button size="icon" variant="secondary" onClick={onClose} aria-label="Close" data-testid="camera-close-btn">
                        <X className="size-4" />
                    </Button>
                </div>

                <div className="relative aspect-[4/3] sm:aspect-video bg-black">
                    {error ? (
                        <div className="absolute inset-0 grid place-items-center p-6 text-center">
                            <div>
                                <p className="text-rose-300 font-medium">Camera unavailable</p>
                                <p className="text-sm text-muted-foreground mt-1">{error}</p>
                                <Button onClick={() => start()} className="mt-4 rounded-full bg-[hsl(var(--primary))]">Try again</Button>
                            </div>
                        </div>
                    ) : (
                        <video ref={videoRef} className="absolute inset-0 h-full w-full object-cover" playsInline muted />
                    )}
                    {/* viewfinder */}
                    <div className="pointer-events-none absolute inset-6 rounded-2xl border-2 border-[hsl(var(--accent))]/60" />
                </div>

                <div className="p-5 flex items-center justify-between gap-4">
                    <div>
                        <div className="font-display text-xl font-semibold flex items-center gap-2">
                            <CamIcon className="size-5 text-[hsl(var(--accent))]" /> Live Scanner
                        </div>
                        <div className="text-xs text-muted-foreground">Point at any text and tap capture</div>
                    </div>
                    <Button
                        onClick={capture}
                        disabled={busy || !!error}
                        className="rounded-full px-6 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                        data-testid="camera-capture-btn"
                    >
                        {busy ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
                        {busy ? "Reading…" : "Capture & Extract"}
                    </Button>
                </div>
            </div>
        </div>
    );
}
