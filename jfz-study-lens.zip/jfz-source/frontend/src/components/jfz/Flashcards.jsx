import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Shuffle, RotateCcw, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getFlashcards } from "@/lib/api";
import { toast } from "sonner";

export default function Flashcards({ text, language }) {
    const [cards, setCards] = useState([]);
    const [idx, setIdx] = useState(0);
    const [flipped, setFlipped] = useState(false);
    const [loading, setLoading] = useState(false);

    const generate = async () => {
        setLoading(true);
        try {
            const c = await getFlashcards(text, 12, language);
            setCards(c);
            setIdx(0);
            setFlipped(false);
            toast.success(`${c.length} flashcards ready`);
        } catch (e) {
            toast.error("Failed to generate", { description: e?.response?.data?.detail || e.message });
        } finally {
            setLoading(false);
        }
    };

    const next = () => {
        setFlipped(false);
        setIdx((i) => (i + 1) % cards.length);
    };
    const prev = () => {
        setFlipped(false);
        setIdx((i) => (i - 1 + cards.length) % cards.length);
    };
    const shuffle = () => {
        setCards((c) => [...c].sort(() => Math.random() - 0.5));
        setIdx(0);
        setFlipped(false);
    };

    if (!cards.length) {
        return (
            <div className="rounded-2xl border border-dashed border-border bg-card/50 p-8 text-center" data-testid="flashcards-empty">
                <h3 className="font-display text-2xl font-semibold">Study Flashcards</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                    Turn your document into spaced-repetition style flashcards. Tap to flip, swipe to move through them.
                </p>
                <Button
                    onClick={generate}
                    disabled={loading}
                    className="mt-5 rounded-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                    data-testid="generate-flashcards-btn"
                >
                    {loading ? <Loader2 className="size-4 animate-spin" /> : <RotateCcw className="size-4" />}
                    Generate Flashcards
                </Button>
            </div>
        );
    }

    const c = cards[idx];
    const isUrdu = language === "urdu";
    const isHindi = language === "hindi";
    const scriptClass = isUrdu ? "font-script-urdu" : isHindi ? "font-script-hindi" : "";

    return (
        <div data-testid="flashcards-deck">
            <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">
                    Card {idx + 1} / {cards.length}
                </span>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={shuffle} data-testid="flashcards-shuffle-btn" className="rounded-full">
                        <Shuffle className="size-3.5" /> Shuffle
                    </Button>
                    <Button variant="outline" size="sm" onClick={generate} data-testid="flashcards-regenerate-btn" className="rounded-full">
                        <RotateCcw className="size-3.5" /> Regenerate
                    </Button>
                </div>
            </div>

            <div className="flashcard-perspective h-72 sm:h-80">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 8, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.98 }}
                        transition={{ duration: 0.25 }}
                        className="h-full"
                    >
                        <button
                            onClick={() => setFlipped((f) => !f)}
                            className={`flashcard-flip relative h-full w-full rounded-3xl ${flipped ? "is-flipped" : ""}`}
                            data-testid="flashcard-card-btn"
                            aria-label="Flip card"
                        >
                            <div className="flashcard-face absolute inset-0 rounded-3xl border border-border bg-card p-8 grid place-items-center text-center shadow-lg">
                                <div>
                                    <div className="text-[11px] uppercase tracking-[0.2em] text-[hsl(var(--accent))]">Question</div>
                                    <div className={`mt-4 font-display text-2xl sm:text-3xl font-semibold ${scriptClass}`}>{c.front}</div>
                                    <div className="mt-6 text-xs text-muted-foreground">Tap to reveal</div>
                                </div>
                            </div>
                            <div className="flashcard-face flashcard-back absolute inset-0 rounded-3xl border border-[hsl(var(--primary))]/30 bg-[hsl(var(--primary))]/5 p-8 grid place-items-center text-center shadow-lg">
                                <div>
                                    <div className="text-[11px] uppercase tracking-[0.2em] text-[hsl(var(--primary))]">Answer</div>
                                    <div className={`mt-4 text-lg sm:text-xl leading-relaxed ${scriptClass}`}>{c.back}</div>
                                </div>
                            </div>
                        </button>
                    </motion.div>
                </AnimatePresence>
            </div>

            <div className="mt-4 flex items-center justify-between">
                <Button variant="outline" onClick={prev} className="rounded-full" data-testid="flashcards-prev-btn">
                    <ChevronLeft className="size-4" /> Previous
                </Button>
                <Button onClick={next} className="rounded-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90" data-testid="flashcards-next-btn">
                    Next <ChevronRight className="size-4" />
                </Button>
            </div>
        </div>
    );
}
