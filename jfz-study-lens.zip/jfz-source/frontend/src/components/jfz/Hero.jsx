import React from "react";
import { motion } from "framer-motion";
import { FileText, ImageIcon, Sparkles, Languages, BookOpen, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";

const STATS = [
    { icon: Languages, k: "3", l: "Languages" },
    { icon: Brain, k: "9+", l: "AI Tools" },
    { icon: BookOpen, k: "0", l: "Logins Needed" },
];

export default function Hero({ onPickFile, onPickImage }) {
    const goUpload = () => document.getElementById("upload")?.scrollIntoView({ behavior: "smooth" });

    return (
        <section id="home" className="relative overflow-hidden hero-pattern">
            <div className="relative mx-auto max-w-7xl px-5 sm:px-8 pt-12 sm:pt-20 lg:pt-28 pb-16 lg:pb-24">
                <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-center">
                    <motion.div
                        initial={{ opacity: 0, y: 18 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className="lg:col-span-7"
                    >
                        <div className="inline-flex items-center gap-2 rounded-full border border-[hsl(var(--accent))]/40 bg-[hsl(var(--accent))]/10 px-3.5 py-1.5 text-xs font-medium text-[hsl(var(--accent-foreground))]">
                            <Sparkles className="size-3.5 text-[hsl(var(--accent))]" />
                            AI-powered · Urdu · Hindi · English
                        </div>

                        <h1 className="mt-6 font-display text-[2.4rem] sm:text-5xl lg:text-6xl font-semibold leading-[1.05] tracking-tight">
                            Understand any subject in{" "}
                            <span className="relative inline-block">
                                <span className="text-[hsl(var(--primary))]">any language.</span>
                                <span className="absolute -bottom-1 left-0 h-[3px] w-full bg-[hsl(var(--accent))] rounded-full" />
                            </span>
                        </h1>

                        <p className="mt-5 max-w-2xl text-base sm:text-lg text-muted-foreground leading-relaxed">
                            Upload a PDF, image, handwritten note, screenshot or book page — and instantly
                            <span className="text-foreground font-medium"> extract, translate, explain, listen, summarise</span> and
                            <span className="text-foreground font-medium"> revise </span>
                            with AI. Built for students, teachers, madarsa learners, and parents.
                        </p>

                        <div className="mt-8 flex flex-wrap gap-3">
                            <Button
                                size="lg"
                                onClick={() => {
                                    onPickFile();
                                    setTimeout(goUpload, 50);
                                }}
                                className="rounded-full px-6 bg-[hsl(var(--primary))] text-primary-foreground hover:bg-[hsl(var(--primary))]/90 shadow-lg shadow-[hsl(var(--primary))]/20"
                                data-testid="hero-upload-pdf-btn"
                            >
                                <FileText className="size-4" /> Upload PDF
                            </Button>
                            <Button
                                size="lg"
                                variant="outline"
                                onClick={() => {
                                    onPickImage();
                                    setTimeout(goUpload, 50);
                                }}
                                className="rounded-full px-6 border-[hsl(var(--accent))] bg-[hsl(var(--accent))]/15 text-[hsl(var(--accent-foreground))] hover:bg-[hsl(var(--accent))]/25"
                                data-testid="hero-upload-image-btn"
                            >
                                <ImageIcon className="size-4" /> Upload Image
                            </Button>
                        </div>

                        <p className="mt-4 text-xs text-muted-foreground">
                            No account · No sign up · Free to start instantly
                        </p>

                        <div className="mt-10 grid grid-cols-3 gap-4 max-w-md">
                            {STATS.map((s, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.3 + i * 0.08, duration: 0.5 }}
                                    className="rounded-xl border border-border bg-card/60 px-3 py-3 backdrop-blur"
                                >
                                    <s.icon className="size-4 text-[hsl(var(--primary))]" />
                                    <div className="mt-2 font-display text-2xl font-semibold">{s.k}</div>
                                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{s.l}</div>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.96 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.7, delay: 0.15 }}
                        className="lg:col-span-5"
                    >
                        <PreviewCard />
                    </motion.div>
                </div>
            </div>
        </section>
    );
}

function PreviewCard() {
    return (
        <div className="relative">
            <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-[hsl(var(--accent))]/20 via-transparent to-[hsl(var(--primary))]/25 blur-2xl" />
            <div className="relative rounded-3xl border border-border bg-card shadow-xl overflow-hidden">
                <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-muted/40">
                    <div className="flex items-center gap-2">
                        <span className="size-2.5 rounded-full bg-rose-400/70" />
                        <span className="size-2.5 rounded-full bg-amber-400/80" />
                        <span className="size-2.5 rounded-full bg-emerald-500/80" />
                    </div>
                    <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Study Lens · Live</div>
                </div>
                <div className="p-5 sm:p-7">
                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Extracted</div>
                    <p className="mt-2 text-foreground/90 leading-relaxed">
                        The Quran was revealed in the holy month of Ramadan. Fasting in this month
                        is the fourth pillar of Islam and brings discipline, gratitude and compassion…
                    </p>
                    <div className="my-5 h-px w-full bg-border" />
                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Translated · Urdu</div>
                    <p className="mt-2 font-script-urdu text-lg">
                        قرآن مقدّس رمضان کے مہینے میں نازل ہوا۔ اِس مہینے کا روزہ اسلام کا چوتھا رکن ہے
                        جو نظم، شکر گزاری اور ہمدردی پیدا کرتا ہے۔
                    </p>
                    <div className="mt-6 flex flex-wrap gap-2">
                        {["Explain Simply", "Like a Teacher", "Summarise", "Quick Notes", "10 MCQs"].map((b) => (
                            <span
                                key={b}
                                className="rounded-full border border-border bg-background px-3 py-1 text-[11px] font-medium text-foreground/70"
                            >
                                {b}
                            </span>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
