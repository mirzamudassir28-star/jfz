import React from "react";
import { Instagram, Youtube } from "lucide-react";
import Logo from "@/components/jfz/Logo";

const INSTAGRAM_URL = "https://www.instagram.com/jamiahfatimatuzzahra?igsh=MTVibXlmMHllNXg5Ng==";
const YOUTUBE_URL = "https://youtube.com/@jamiahfatimahtuzzahra?si=5O-SqkYkn21lwiRP";

export default function Footer() {
    const year = new Date().getFullYear();
    return (
        <footer className="border-t border-border bg-card/40" data-testid="footer">
            <div className="mx-auto max-w-7xl px-5 sm:px-8 py-12 sm:py-16">
                <div className="grid lg:grid-cols-12 gap-10">
                    <div className="lg:col-span-7">
                        <Logo size={52} />
                        <p className="mt-5 text-sm text-muted-foreground max-w-md leading-relaxed">
                            JAMIAH FATIMAH TUZ ZAHRA ONLINE EDUCATIONAL CENTRE — empowering students,
                            teachers and madarsa learners through accessible, multilingual AI learning tools.
                        </p>
                        <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-[hsl(var(--accent))]">
                            Powered by JFZ Digital Solutions
                        </p>
                    </div>

                    <div className="lg:col-span-5">
                        <div className="font-display text-lg font-semibold">Follow</div>
                        <div className="mt-4 flex flex-wrap gap-2">
                            <Social href={INSTAGRAM_URL} Icon={Instagram} label="Instagram" testId="footer-instagram" />
                            <Social href={YOUTUBE_URL} Icon={Youtube} label="YouTube" testId="footer-youtube" />
                        </div>
                    </div>
                </div>

                <div className="mt-12 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
                    <span>© {year} JFZ Digital Solutions. All rights reserved.</span>
                    <span className="font-script-urdu text-base">رَبِّ زِدْنِي عِلْمًا</span>
                </div>
            </div>
        </footer>
    );
}

function Social({ href, Icon, label, testId }) {
    return (
        <a
            href={href}
            target="_blank"
            rel="noreferrer"
            data-testid={testId}
            className="grid size-10 place-items-center rounded-full border border-border bg-background hover:border-[hsl(var(--primary))]/60 hover:bg-[hsl(var(--primary))]/10 transition-colors"
            aria-label={label}
        >
            <Icon className="size-4" />
        </a>
    );
}
