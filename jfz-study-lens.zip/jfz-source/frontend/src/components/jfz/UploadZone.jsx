import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { UploadCloud, FileText, ImageIcon, Camera, Loader2, FileUp } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { extractText } from "@/lib/api";

const ACCEPT = ".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp";

export default function UploadZone({ onExtracted, onScan }) {
    const fileInputRef = useRef(null);
    const imageInputRef = useRef(null);
    const [dragging, setDragging] = useState(false);
    const [busy, setBusy] = useState(false);
    const [progressLabel, setProgressLabel] = useState("");

    const handleFile = async (file) => {
        if (!file) return;
        const sizeMB = file.size / 1024 / 1024;
        if (sizeMB > 25) {
            toast.error("File too large", { description: "Please upload files under 25MB." });
            return;
        }
        setBusy(true);
        setProgressLabel("Reading your file…");
        try {
            setProgressLabel("Extracting text with AI…");
            const data = await extractText(file);
            if (!data.text || !data.text.trim()) {
                toast.warning("No text detected", { description: "Try a clearer image or a different page." });
            } else {
                toast.success("Text extracted!", { description: `${data.text.length} characters · ${data.detected_language}` });
            }
            onExtracted(data, file.name);
        } catch (e) {
            console.error(e);
            toast.error("Failed to extract", { description: e?.response?.data?.detail || e.message });
        } finally {
            setBusy(false);
            setProgressLabel("");
        }
    };

    const onDrop = (e) => {
        e.preventDefault();
        setDragging(false);
        const f = e.dataTransfer.files?.[0];
        if (f) handleFile(f);
    };

    return (
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-12 sm:py-16">
            <div className="grid lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5">
                    <div className="gold-underline mb-4" />
                    <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight">
                        Drop it in. <br />
                        We&apos;ll do the rest.
                    </h2>
                    <p className="mt-4 text-muted-foreground leading-relaxed">
                        Upload a PDF, JPG, PNG, WEBP, screenshot, handwritten note or a photo from your
                        camera. JFZ Study Lens extracts the text, then unlocks translations, explanations,
                        Q&amp;A, summaries, notes, MCQs, flashcards and audio reading — all in one place.
                    </p>
                    <ul className="mt-6 space-y-2 text-sm text-foreground/80">
                        <li className="flex items-center gap-2">
                            <span className="size-1.5 rounded-full bg-[hsl(var(--accent))]" /> Handwriting, printed text, Urdu, Hindi, English
                        </li>
                        <li className="flex items-center gap-2">
                            <span className="size-1.5 rounded-full bg-[hsl(var(--accent))]" /> Works on mobile and desktop
                        </li>
                        <li className="flex items-center gap-2">
                            <span className="size-1.5 rounded-full bg-[hsl(var(--accent))]" /> Up to 25MB · No account needed
                        </li>
                    </ul>
                </div>

                <div className="lg:col-span-7">
                    <motion.div
                        initial={{ opacity: 0, y: 16 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5 }}
                        onDragOver={(e) => {
                            e.preventDefault();
                            setDragging(true);
                        }}
                        onDragLeave={() => setDragging(false)}
                        onDrop={onDrop}
                        data-testid="upload-zone"
                        className={`relative rounded-3xl border-2 border-dashed bg-card/70 p-8 sm:p-12 text-center transition-all ${
                            dragging
                                ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent))]/10 scale-[1.01]"
                                : "border-border hover:border-[hsl(var(--primary))]/60"
                        }`}
                    >
                        <div className="mx-auto grid size-16 place-items-center rounded-2xl bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]">
                            <UploadCloud className="size-8" />
                        </div>
                        <h3 className="mt-5 font-display text-2xl font-semibold">
                            {busy ? "Working on it…" : "Drag & drop your file"}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            {busy ? progressLabel : "or choose how to upload"}
                        </p>

                        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                            <Button
                                onClick={() => fileInputRef.current?.click()}
                                disabled={busy}
                                className="rounded-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                                data-testid="upload-pdf-btn"
                            >
                                {busy ? <Loader2 className="size-4 animate-spin" /> : <FileText className="size-4" />}
                                Upload PDF
                            </Button>
                            <Button
                                onClick={() => imageInputRef.current?.click()}
                                disabled={busy}
                                variant="outline"
                                className="rounded-full border-[hsl(var(--accent))] bg-[hsl(var(--accent))]/15 hover:bg-[hsl(var(--accent))]/25 text-[hsl(var(--accent-foreground))]"
                                data-testid="upload-image-btn"
                            >
                                <ImageIcon className="size-4" /> Upload Image
                            </Button>
                            <Button
                                onClick={onScan}
                                disabled={busy}
                                variant="ghost"
                                className="rounded-full"
                                data-testid="upload-camera-btn"
                            >
                                <Camera className="size-4" /> Live Camera
                            </Button>
                        </div>

                        <p className="mt-6 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                            PDF · JPG · PNG · WEBP · Up to 25MB
                        </p>

                        <input
                            id="upload-file-input"
                            ref={fileInputRef}
                            type="file"
                            accept={ACCEPT}
                            hidden
                            onChange={(e) => handleFile(e.target.files?.[0])}
                            data-testid="upload-file-input"
                        />
                        <input
                            id="upload-image-input"
                            ref={imageInputRef}
                            type="file"
                            accept="image/*"
                            hidden
                            onChange={(e) => handleFile(e.target.files?.[0])}
                            data-testid="upload-image-input"
                        />

                        {busy && (
                            <div className="pointer-events-none absolute inset-0 rounded-3xl overflow-hidden">
                                <div
                                    className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-[hsl(var(--primary))] via-[hsl(var(--accent))] to-[hsl(var(--primary))] bg-[length:200%_100%] animate-shimmer"
                                />
                            </div>
                        )}
                    </motion.div>
                </div>
            </div>
        </div>
    );
}
