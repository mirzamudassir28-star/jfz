import React from "react";

export default function About() {
    return (
        <section id="about" className="scroll-mt-24 border-t border-border">
            <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16 sm:py-24">
                <div className="max-w-3xl">
                    <div className="text-[11px] uppercase tracking-[0.22em] text-[hsl(var(--accent))]">About</div>
                    <h2 className="mt-2 font-display text-3xl sm:text-5xl font-semibold leading-tight">
                        Built by{" "}
                        <span className="text-[hsl(var(--primary))]">Jamiah Fatimah Tuz Zahra</span>{" "}
                        Online Educational Centre.
                    </h2>
                    <p className="mt-5 text-muted-foreground leading-relaxed">
                        JFZ Study Lens was created so any learner — a madarsa student studying Urdu texts, a school child
                        revising Hindi notes, a parent helping with English homework — can{" "}
                        <span className="text-foreground font-medium">understand anything in their own language</span>,
                        instantly, without barriers, without accounts.
                    </p>
                    <p className="mt-4 text-muted-foreground leading-relaxed">
                        Powered by modern AI vision and language models, JFZ Digital Solutions brings premium learning tools
                        to everyone, free of friction and free of cost to begin.
                    </p>

                    <dl className="mt-8 grid grid-cols-3 gap-4 text-sm max-w-xl">
                        <Stat k="3" l="Languages" />
                        <Stat k="12+" l="Study tools" />
                        <Stat k="∞" l="Curiosity" />
                    </dl>
                </div>
            </div>
        </section>
    );
}

function Stat({ k, l }) {
    return (
        <div className="rounded-xl border border-border bg-card/60 p-4">
            <div className="font-display text-3xl font-semibold text-[hsl(var(--primary))]">{k}</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">{l}</div>
        </div>
    );
}
