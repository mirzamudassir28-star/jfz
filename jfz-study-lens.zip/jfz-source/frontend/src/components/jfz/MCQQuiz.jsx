import React, { useMemo, useState } from "react";
import { Loader2, CheckCircle2, XCircle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getMCQs } from "@/lib/api";
import { toast } from "sonner";

export default function MCQQuiz({ text, language }) {
    const [count, setCount] = useState("10");
    const [questions, setQuestions] = useState([]);
    const [answers, setAnswers] = useState({}); // idx -> chosen option idx
    const [submitted, setSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);

    const generate = async () => {
        setLoading(true);
        setQuestions([]);
        setAnswers({});
        setSubmitted(false);
        try {
            const qs = await getMCQs(text, parseInt(count, 10), language);
            setQuestions(qs);
            toast.success(`${qs.length} MCQs generated`);
        } catch (e) {
            toast.error("Failed to generate", { description: e?.response?.data?.detail || e.message });
        } finally {
            setLoading(false);
        }
    };

    const score = useMemo(() => {
        if (!submitted) return 0;
        let s = 0;
        questions.forEach((q, i) => {
            if (answers[i] === q.answer_index) s += 1;
        });
        return s;
    }, [submitted, questions, answers]);

    const scriptClass = language === "urdu" ? "font-script-urdu" : language === "hindi" ? "font-script-hindi" : "";

    return (
        <div data-testid="mcq-section">
            <div className="flex flex-wrap items-center gap-3">
                <Select value={count} onValueChange={setCount}>
                    <SelectTrigger className="w-32 rounded-full" data-testid="mcq-count-select">
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="10">10 MCQs</SelectItem>
                        <SelectItem value="20">20 MCQs</SelectItem>
                        <SelectItem value="50">50 MCQs</SelectItem>
                    </SelectContent>
                </Select>
                <Button
                    onClick={generate}
                    disabled={loading}
                    className="rounded-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                    data-testid="mcq-generate-btn"
                >
                    {loading ? <Loader2 className="size-4 animate-spin" /> : <RotateCcw className="size-4" />}
                    Generate Quiz
                </Button>
                {questions.length > 0 && !submitted && (
                    <Button
                        variant="outline"
                        className="rounded-full border-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"
                        disabled={Object.keys(answers).length < questions.length}
                        onClick={() => setSubmitted(true)}
                        data-testid="mcq-submit-btn"
                    >
                        Submit Answers ({Object.keys(answers).length}/{questions.length})
                    </Button>
                )}
            </div>

            {submitted && (
                <div className="mt-5 rounded-2xl border border-[hsl(var(--primary))]/30 bg-[hsl(var(--primary))]/5 p-5" data-testid="mcq-score">
                    <div className="font-display text-3xl font-semibold">
                        Score: <span className="text-[hsl(var(--primary))]">{score}</span>
                        <span className="text-muted-foreground"> / {questions.length}</span>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                        {Math.round((score / questions.length) * 100)}% correct
                    </div>
                </div>
            )}

            <div className="mt-6 space-y-5">
                {questions.map((q, qi) => {
                    const chosen = answers[qi];
                    return (
                        <div key={qi} className="rounded-2xl border border-border bg-card p-5" data-testid={`mcq-question-${qi}`}>
                            <div className={`font-medium ${scriptClass}`}>
                                <span className="text-[hsl(var(--accent))] mr-2">Q{qi + 1}.</span>
                                {q.q}
                            </div>
                            <div className="mt-3 grid sm:grid-cols-2 gap-2">
                                {q.options.map((opt, oi) => {
                                    const isChosen = chosen === oi;
                                    const isCorrect = submitted && oi === q.answer_index;
                                    const isWrong = submitted && isChosen && oi !== q.answer_index;
                                    return (
                                        <button
                                            key={oi}
                                            disabled={submitted}
                                            onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                                            data-testid={`mcq-option-${qi}-${oi}`}
                                            className={`group flex items-start gap-3 rounded-xl border px-4 py-3 text-left text-sm transition-all ${
                                                isCorrect
                                                    ? "border-emerald-500 bg-emerald-500/10"
                                                    : isWrong
                                                    ? "border-rose-500 bg-rose-500/10"
                                                    : isChosen
                                                    ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10"
                                                    : "border-border hover:border-[hsl(var(--primary))]/60 hover:bg-muted"
                                            } ${scriptClass}`}
                                        >
                                            <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full border border-current/40 text-[11px] font-semibold">
                                                {String.fromCharCode(65 + oi)}
                                            </span>
                                            <span className="flex-1">{opt}</span>
                                            {isCorrect && <CheckCircle2 className="size-4 text-emerald-600 shrink-0" />}
                                            {isWrong && <XCircle className="size-4 text-rose-600 shrink-0" />}
                                        </button>
                                    );
                                })}
                            </div>
                            {submitted && q.explanation && (
                                <div className={`mt-3 rounded-lg bg-muted/60 p-3 text-sm text-muted-foreground ${scriptClass}`}>
                                    <strong className="text-foreground">Why: </strong>
                                    {q.explanation}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
