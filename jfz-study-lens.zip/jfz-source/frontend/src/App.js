import React, { useEffect, useState } from "react";
import "@/App.css";
import { Toaster } from "sonner";
import Navbar from "@/components/jfz/Navbar";
import Hero from "@/components/jfz/Hero";
import UploadZone from "@/components/jfz/UploadZone";
import Reader from "@/components/jfz/Reader";
import Features from "@/components/jfz/Features";
import About from "@/components/jfz/About";
import Footer from "@/components/jfz/Footer";
import CameraScanner from "@/components/jfz/CameraScanner";

export default function App() {
    // Theme
    const [theme, setTheme] = useState(() => {
        if (typeof window === "undefined") return "light";
        return localStorage.getItem("jfz-theme") || "light";
    });
    useEffect(() => {
        const root = document.documentElement;
        if (theme === "dark") root.classList.add("dark");
        else root.classList.remove("dark");
        localStorage.setItem("jfz-theme", theme);
    }, [theme]);

    // Session state
    const [session, setSession] = useState(null); // {session_id, text, detected_language, filename}
    const [showCamera, setShowCamera] = useState(false);

    const handleExtracted = (data, filename) => {
        setSession({ ...data, filename });
        // Scroll to reader
        setTimeout(() => {
            document.getElementById("reader")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
    };

    return (
        <div className="App min-h-screen bg-background text-foreground">
            <Toaster richColors position="top-center" />
            <Navbar theme={theme} setTheme={setTheme} onScan={() => setShowCamera(true)} />

            <main>
                <Hero
                    onPickFile={(f) => document.getElementById("upload-file-input")?.click()}
                    onPickImage={() => document.getElementById("upload-image-input")?.click()}
                    onScan={() => setShowCamera(true)}
                />
                <section id="upload" className="scroll-mt-24">
                    <UploadZone onExtracted={handleExtracted} onScan={() => setShowCamera(true)} />
                </section>

                {session && (
                    <section id="reader" className="scroll-mt-24">
                        <Reader session={session} onReset={() => setSession(null)} />
                    </section>
                )}

                <Features />
                <About />
            </main>

            <Footer />

            {showCamera && (
                <CameraScanner
                    onClose={() => setShowCamera(false)}
                    onCaptured={(data, filename) => {
                        setShowCamera(false);
                        handleExtracted(data, filename);
                    }}
                />
            )}
        </div>
    );
}
