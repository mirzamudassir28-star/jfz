"""JFZ Study Lens — Backend (FastAPI + Gemini multimodal)."""
import os
import re
import json
import uuid
import base64
import logging
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Optional, Literal

from fastapi import FastAPI, APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient

from emergentintegrations.llm.chat import (
    LlmChat,
    UserMessage,
    FileContentWithMimeType,
    ImageContent,
)

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

# ----- Config -----
MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]
EMERGENT_LLM_KEY = os.environ.get("EMERGENT_LLM_KEY", "")

GEMINI_PROVIDER = "gemini"
GEMINI_MODEL = "gemini-3-flash-preview"

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

app = FastAPI(title="JFZ Study Lens API")
api = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("jfz")

# ----- Helpers -----
def make_chat(session_id: str, system: str) -> LlmChat:
    return LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message=system,
    ).with_model(GEMINI_PROVIDER, GEMINI_MODEL)


IMAGE_MIMES = {"image/jpeg", "image/jpg", "image/png", "image/webp", "image/heic", "image/heif"}
PDF_MIME = "application/pdf"


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    # remove ```json ... ``` or ``` ... ```
    text = re.sub(r"^```(?:json|JSON)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _parse_json(raw: str):
    raw = _strip_code_fences(raw)
    # try direct parse, else find first { or [
    try:
        return json.loads(raw)
    except Exception:
        match = re.search(r"(\[.*\]|\{.*\})", raw, re.DOTALL)
        if match:
            return json.loads(match.group(1))
        raise


# ----- Models -----
class ExtractResponse(BaseModel):
    session_id: str
    text: str
    detected_language: str = ""


class TextOnly(BaseModel):
    text: str


class TranslateReq(BaseModel):
    text: str
    target: Literal["urdu", "hindi", "english"]


class ExplainReq(BaseModel):
    text: str
    style: Literal["simply", "detailed", "teacher", "child"]
    language: Literal["urdu", "hindi", "english"] = "english"


class AskReq(BaseModel):
    text: str
    question: str
    language: Literal["urdu", "hindi", "english"] = "english"


class SummaryReq(BaseModel):
    text: str
    mode: Literal["short", "detailed", "bullet"]
    language: Literal["urdu", "hindi", "english"] = "english"


class NotesReq(BaseModel):
    text: str
    mode: Literal["quick", "revision", "exam"]
    language: Literal["urdu", "hindi", "english"] = "english"


class MCQReq(BaseModel):
    text: str
    count: int = 10
    language: Literal["urdu", "hindi", "english"] = "english"


class FlashReq(BaseModel):
    text: str
    count: int = 12
    language: Literal["urdu", "hindi", "english"] = "english"


# ----- Endpoints -----
@api.get("/")
async def root():
    return {"service": "JFZ Study Lens", "ok": True}


@api.post("/extract", response_model=ExtractResponse)
async def extract(file: UploadFile = File(...)):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(500, "LLM key not configured")

    content_type = (file.content_type or "").lower()
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty file")

    # decide mime
    filename = (file.filename or "").lower()
    if content_type not in IMAGE_MIMES and content_type != PDF_MIME:
        if filename.endswith(".pdf"):
            content_type = PDF_MIME
        elif filename.endswith((".jpg", ".jpeg")):
            content_type = "image/jpeg"
        elif filename.endswith(".png"):
            content_type = "image/png"
        elif filename.endswith(".webp"):
            content_type = "image/webp"
        else:
            raise HTTPException(400, f"Unsupported file type: {content_type or filename}")

    session_id = str(uuid.uuid4())
    system_prompt = (
        "You are an expert OCR engine for printed and handwritten content in English, "
        "Urdu (Nastaliq script), Hindi (Devanagari), and Arabic. Extract ALL readable text "
        "EXACTLY as it appears, preserving line breaks, paragraphs, headings, lists, and tables "
        "(use simple markdown). Do not translate, do not summarize, do not add commentary. "
        "If the page has diagrams or figures, briefly note them in [square brackets]. "
        "Return ONLY the extracted text."
    )
    chat = make_chat(session_id, system_prompt)

    user_msg: UserMessage
    if content_type == PDF_MIME:
        # write to temp file for FileContentWithMimeType
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        tmp.write(data)
        tmp.flush()
        tmp.close()
        file_content = FileContentWithMimeType(mime_type=PDF_MIME, file_path=tmp.name)
        user_msg = UserMessage(text="Extract all text from this PDF.", file_contents=[file_content])
    else:
        b64 = base64.b64encode(data).decode("ascii")
        img = ImageContent(image_base64=b64)
        user_msg = UserMessage(text="Extract all text from this image.", file_contents=[img])

    try:
        extracted = await chat.send_message(user_msg)
    except Exception as e:
        log.exception("OCR failed")
        raise HTTPException(500, f"OCR failed: {e}")

    extracted = (extracted or "").strip()

    # detect language quickly
    lang = "english"
    if re.search(r"[\u0600-\u06FF]", extracted):
        lang = "urdu"
    elif re.search(r"[\u0900-\u097F]", extracted):
        lang = "hindi"

    doc = {
        "_id": session_id,
        "text": extracted,
        "filename": file.filename,
        "mime": content_type,
        "language": lang,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.sessions.insert_one(doc)

    return ExtractResponse(session_id=session_id, text=extracted, detected_language=lang)


async def _llm_text(system: str, prompt: str, session_id: Optional[str] = None) -> str:
    sid = session_id or str(uuid.uuid4())
    chat = make_chat(sid, system)
    try:
        return (await chat.send_message(UserMessage(text=prompt))).strip()
    except Exception as e:
        log.exception("LLM call failed")
        raise HTTPException(500, f"LLM error: {e}")


LANG_NAMES = {"urdu": "Urdu (in Nastaliq script)", "hindi": "Hindi (in Devanagari script)", "english": "English"}


@api.post("/translate")
async def translate(req: TranslateReq):
    system = (
        "You are a master translator for educational content (English ↔ Urdu ↔ Hindi). "
        "Preserve the meaning, tone, line breaks and structure. Use natural fluent language. "
        "Return ONLY the translated text — no preface, no notes."
    )
    prompt = f"Translate the following text into {LANG_NAMES[req.target]}:\n\n---\n{req.text}\n---"
    out = await _llm_text(system, prompt)
    return {"translation": out, "target": req.target}


STYLE_INSTRUCTIONS = {
    "simply": "Explain in very simple words anyone can understand. Keep it short and friendly.",
    "detailed": "Explain in depth with background, examples, and analogies. Use clear headings.",
    "teacher": "Explain step-by-step like an experienced classroom teacher. Use examples, recap key points at the end.",
    "child": "Explain like you are talking to a 7-year-old child. Use very easy words, tiny sentences, and one fun analogy.",
}


@api.post("/explain")
async def explain(req: ExplainReq):
    system = (
        "You are a patient, knowledgeable tutor. "
        f"{STYLE_INSTRUCTIONS[req.style]} "
        f"Respond in {LANG_NAMES[req.language]}. Use markdown."
    )
    prompt = f"Explain the following content:\n\n---\n{req.text}\n---"
    return {"explanation": await _llm_text(system, prompt), "style": req.style}


@api.post("/ask")
async def ask(req: AskReq):
    system = (
        "You are a helpful study assistant. Answer the user's question USING ONLY the provided document content. "
        "If the answer is not in the document, say so politely and give the closest related info from the document. "
        f"Respond in {LANG_NAMES[req.language]}. Use markdown."
    )
    prompt = (
        f"DOCUMENT:\n---\n{req.text}\n---\n\n"
        f"QUESTION: {req.question}\n\nAnswer based only on the document above."
    )
    return {"answer": await _llm_text(system, prompt)}


SUMMARY_INSTRUCTIONS = {
    "short": "Write a concise 2-3 sentence summary capturing the main idea.",
    "detailed": "Write a thorough multi-paragraph summary with all key ideas, sub-topics and conclusions. Use markdown headings.",
    "bullet": "Write a clean bullet-point summary. 6-12 bullets, each crisp and self-contained.",
}


@api.post("/summary")
async def summary(req: SummaryReq):
    system = (
        f"You are an expert at summarizing study material. {SUMMARY_INSTRUCTIONS[req.mode]} "
        f"Respond in {LANG_NAMES[req.language]}."
    )
    prompt = f"Summarize the following text:\n\n---\n{req.text}\n---"
    return {"summary": await _llm_text(system, prompt), "mode": req.mode}


NOTES_INSTRUCTIONS = {
    "quick": "Quick study notes — a short list of the most important takeaways.",
    "revision": "Revision notes — well-organized with headings, sub-points and brief explanations, ideal for last-minute revision.",
    "exam": "Exam-focused notes — definitions, formulas, dates, key terms, and likely exam points highlighted.",
}


@api.post("/notes")
async def notes(req: NotesReq):
    system = (
        f"You are an expert note-maker for students. {NOTES_INSTRUCTIONS[req.mode]} "
        f"Use clear markdown headings, bullets and bold key terms. Respond in {LANG_NAMES[req.language]}."
    )
    prompt = f"Generate notes from:\n\n---\n{req.text}\n---"
    return {"notes": await _llm_text(system, prompt), "mode": req.mode}


@api.post("/mcq")
async def mcq(req: MCQReq):
    count = max(1, min(50, req.count))
    system = (
        "You are an exam-question writer. Generate multiple-choice questions strictly from the provided text. "
        "Return ONLY valid JSON in this exact shape: "
        '{"questions":[{"q":"...","options":["A","B","C","D"],"answer_index":0,"explanation":"..."}]}. '
        "answer_index is 0-based. No markdown, no commentary."
    )
    prompt = (
        f"Create {count} MCQs (4 options each) in {LANG_NAMES[req.language]} from the content below.\n\n"
        f"---\n{req.text}\n---"
    )
    raw = await _llm_text(system, prompt)
    try:
        parsed = _parse_json(raw)
        questions = parsed.get("questions", parsed if isinstance(parsed, list) else [])
    except Exception:
        raise HTTPException(500, "Could not parse MCQ output from model")
    return {"questions": questions, "count": len(questions)}


@api.post("/flashcards")
async def flashcards(req: FlashReq):
    count = max(1, min(50, req.count))
    system = (
        "You are a study-flashcard generator. Generate concise flashcards from the provided text. "
        "Return ONLY valid JSON: "
        '{"cards":[{"front":"...","back":"..."}]}. '
        "Front = a question or key term; Back = the answer / definition. No markdown."
    )
    prompt = (
        f"Create {count} flashcards in {LANG_NAMES[req.language]} from:\n\n---\n{req.text}\n---"
    )
    raw = await _llm_text(system, prompt)
    try:
        parsed = _parse_json(raw)
        cards = parsed.get("cards", parsed if isinstance(parsed, list) else [])
    except Exception:
        raise HTTPException(500, "Could not parse flashcards output")
    return {"cards": cards, "count": len(cards)}


# Register router & middleware
app.include_router(api)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown():
    client.close()
