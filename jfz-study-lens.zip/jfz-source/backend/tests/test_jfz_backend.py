"""JFZ Study Lens — Backend API tests.

Covers: health, OCR (image+pdf), translate, explain, ask, summary, notes, mcq, flashcards.
"""
import io
import os
import re
import time

import pytest
import requests
from PIL import Image, ImageDraw, ImageFont
from fpdf import FPDF

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

SAMPLE_TEXT = (
    "Photosynthesis is the process by which green plants use sunlight, water, "
    "and carbon dioxide to make food in the form of glucose and release oxygen. "
    "It occurs mainly in the chloroplasts of plant cells and is essential for life on Earth."
)


# ---------- helpers ----------
def _post_json_retry(path, payload, retries=2, sleep=4, timeout=120):
    """POST JSON; retry once on budget/transient errors."""
    last = None
    for i in range(retries + 1):
        r = requests.post(f"{API}{path}", json=payload, timeout=timeout)
        last = r
        if r.status_code == 200:
            return r
        body = r.text.lower()
        if "budget" in body or "rate" in body or r.status_code in (429, 500, 502, 503):
            time.sleep(sleep)
            continue
        return r
    return last


def _make_image_bytes(text="Photosynthesis is the process by which green plants use sunlight to make food."):
    img = Image.new("RGB", (1000, 400), color="white")
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
    except Exception:
        font = ImageFont.load_default()
    # wrap a bit
    y = 40
    for line in [
        "Photosynthesis is the process by which",
        "green plants use sunlight, water, and",
        "carbon dioxide to make food (glucose).",
        "It releases oxygen as a by-product.",
    ]:
        d.text((40, y), line, fill="black", font=font)
        y += 60
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=90)
    buf.seek(0)
    return buf


def _make_pdf_bytes():
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", size=16)
    pdf.cell(0, 10, "JFZ Study Lens Test PDF", ln=1)
    pdf.set_font("Helvetica", size=12)
    pdf.multi_cell(
        0, 8,
        "Photosynthesis converts sunlight, water and carbon dioxide into glucose and oxygen. "
        "This is essential for life on Earth."
    )
    out = pdf.output(dest="S")
    if isinstance(out, str):
        out = out.encode("latin-1")
    return io.BytesIO(bytes(out))


# ---------- Health ----------
class TestHealth:
    def test_root(self):
        r = requests.get(f"{API}/", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert data.get("ok") is True
        assert "service" in data


# ---------- OCR extract ----------
class TestExtract:
    def test_extract_image_jpg(self):
        buf = _make_image_bytes()
        files = {"file": ("test.jpg", buf, "image/jpeg")}
        r = requests.post(f"{API}/extract", files=files, timeout=180)
        assert r.status_code == 200, f"extract failed: {r.status_code} {r.text[:300]}"
        data = r.json()
        assert "session_id" in data and data["session_id"]
        assert "text" in data and isinstance(data["text"], str) and len(data["text"]) > 0
        assert "detected_language" in data
        # should contain at least one of the expected words
        lc = data["text"].lower()
        assert any(w in lc for w in ["photosynthesis", "sunlight", "oxygen", "glucose", "plants"]), \
            f"OCR text missing expected keywords. Got: {data['text'][:200]}"

    def test_extract_pdf(self):
        buf = _make_pdf_bytes()
        files = {"file": ("test.pdf", buf, "application/pdf")}
        r = requests.post(f"{API}/extract", files=files, timeout=180)
        assert r.status_code == 200, f"extract pdf failed: {r.status_code} {r.text[:300]}"
        data = r.json()
        assert data.get("text"), "PDF extract returned empty text"
        lc = data["text"].lower()
        assert any(w in lc for w in ["photosynthesis", "sunlight", "oxygen", "glucose", "jfz"]), \
            f"PDF text missing expected words. Got: {data['text'][:200]}"


# ---------- Translate ----------
class TestTranslate:
    def test_translate_urdu(self):
        r = _post_json_retry("/translate", {"text": "Hello, how are you?", "target": "urdu"})
        assert r.status_code == 200, r.text[:300]
        out = r.json().get("translation", "")
        assert out, "empty translation"
        assert re.search(r"[\u0600-\u06FF]", out), f"no Urdu/Arabic unicode found: {out[:200]}"

    def test_translate_hindi(self):
        r = _post_json_retry("/translate", {"text": "Hello, how are you?", "target": "hindi"})
        assert r.status_code == 200, r.text[:300]
        out = r.json().get("translation", "")
        assert out, "empty translation"
        assert re.search(r"[\u0900-\u097F]", out), f"no Devanagari unicode found: {out[:200]}"


# ---------- Explain ----------
class TestExplain:
    @pytest.mark.parametrize("style", ["simply", "detailed", "teacher", "child"])
    def test_explain_styles(self, style):
        r = _post_json_retry("/explain", {"text": SAMPLE_TEXT, "style": style})
        assert r.status_code == 200, f"{style}: {r.text[:300]}"
        out = r.json().get("explanation", "")
        assert isinstance(out, str) and len(out) > 20, f"{style} returned too short: {out[:120]}"


# ---------- Ask ----------
class TestAsk:
    def test_ask_grounded(self):
        r = _post_json_retry("/ask", {
            "text": SAMPLE_TEXT,
            "question": "What gas do plants release during photosynthesis?",
        })
        assert r.status_code == 200, r.text[:300]
        ans = r.json().get("answer", "")
        assert ans and len(ans) > 5
        assert "oxygen" in ans.lower(), f"answer not grounded: {ans[:200]}"


# ---------- Summary ----------
class TestSummary:
    @pytest.mark.parametrize("mode", ["short", "detailed", "bullet"])
    def test_summary_modes(self, mode):
        r = _post_json_retry("/summary", {"text": SAMPLE_TEXT, "mode": mode})
        assert r.status_code == 200, f"{mode}: {r.text[:300]}"
        out = r.json().get("summary", "")
        assert out and len(out) > 10


# ---------- Notes ----------
class TestNotes:
    @pytest.mark.parametrize("mode", ["quick", "revision", "exam"])
    def test_notes_modes(self, mode):
        r = _post_json_retry("/notes", {"text": SAMPLE_TEXT, "mode": mode})
        assert r.status_code == 200, f"{mode}: {r.text[:300]}"
        out = r.json().get("notes", "")
        assert out and len(out) > 10


# ---------- MCQ ----------
class TestMCQ:
    def test_mcq_shape(self):
        r = _post_json_retry("/mcq", {"text": SAMPLE_TEXT, "count": 3})
        assert r.status_code == 200, r.text[:300]
        data = r.json()
        assert "questions" in data and "count" in data
        qs = data["questions"]
        assert isinstance(qs, list) and len(qs) >= 1
        q = qs[0]
        assert "q" in q and isinstance(q["q"], str) and q["q"]
        assert "options" in q and isinstance(q["options"], list) and len(q["options"]) == 4
        assert "answer_index" in q and isinstance(q["answer_index"], int)
        assert 0 <= q["answer_index"] <= 3
        assert "explanation" in q


# ---------- Flashcards ----------
class TestFlashcards:
    def test_flashcards_shape(self):
        r = _post_json_retry("/flashcards", {"text": SAMPLE_TEXT, "count": 3})
        assert r.status_code == 200, r.text[:300]
        data = r.json()
        assert "cards" in data and "count" in data
        cards = data["cards"]
        assert isinstance(cards, list) and len(cards) >= 1
        c = cards[0]
        assert "front" in c and c["front"]
        assert "back" in c and c["back"]
